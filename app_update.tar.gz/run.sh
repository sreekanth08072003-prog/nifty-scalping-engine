#!/bin/bash

# Load credentials from available env files
if [ -f trading.env ]; then
    export $(grep -v '^#' trading.env | xargs)
    echo "[SYSTEM] Credentials loaded from trading.env"
elif [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
    echo "[SYSTEM] Credentials loaded from .env"
else
    echo "[ERROR] No environment file (.env or trading.env) found!"
    exit 1
fi

# Automatically detect IP addresses
export LOCAL_IP=$(hostname -I | awk '{print $1}')
export PUBLIC_IP=$(curl -s -4 https://api.ipify.org)

# Set default Master Contract URL if not already set in .env
export ANGEL_MASTER_URL=${ANGEL_MASTER_URL:-"https://margincalculator.angelbroking.com/OpenApi_0.1/static/allExchangeData.json"}
echo "[SYSTEM] Using Master Contract URL: $ANGEL_MASTER_URL"

# Execute the application
if [ -f "./build/trading_engine" ]; then
    ./build/trading_engine
else
    echo "[ERROR] Binary not found at ./build/trading_engine. Run build.sh first."
fi